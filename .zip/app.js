
import 'dotenv/config.js'

import { Server } from './models/server.js'

const server= new Server()

server.listen()
